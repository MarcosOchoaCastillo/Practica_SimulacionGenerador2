
package practicapool;

public class PracticaPool {

    public static void main(String[] args) {
        frmPrincipal objetoprincipal = new frmPrincipal();
        objetoprincipal.setVisible(true);
        
   
        
    }
    
}
